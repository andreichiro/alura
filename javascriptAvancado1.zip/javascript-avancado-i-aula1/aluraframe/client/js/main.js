var formulario = $(".form");
var tbody = $("table tbody");
var campos = [];

 $(function() {
    adicionaCampos();
});

function adicionaCampos(){
    formulario.submit(function(event) {        
        event.preventDefault();
        var tr = $("<tr>");
        var data = $("#data").val();
        var quantidade = $("#quantidade").val();
        var valor = $("#valor").val();
        var tdVolume = $("<td>");
        tdVolume.text(quantidade * valor);
        campos.push(data, quantidade, valor, tdVolume);
        $(campos).each(function(a) {
            var td = $('<td>');
            td.text(campos[a]);        
            tr.append(td);  
        });
    tr.append(tdVolume);
    tbody.append(tr);
    });
}



