class Negociacaoview extends View {

    constructor(elemento) {
        super(elemento);
    }

    template(model) {
        return `        
            <thead>
                <tr>
                    <th>DATA</th>
                    <th>QUANTIDADE</th>
                    <th>VALOR</th>
                    <th>VOLUME</th>
                </tr>
            </thead>
        <tbody>
            ${model.negociacoes.map(n => {
              return `
                <tr>
                    <td>${DateHelper.dataParaTexto(n.data)}</td>
                    <td>${n.quantidade}</td>
                    <td>${n.valor}</td>
                    <td>${n.volume}</td>
                </tr>
              `
              }).join('')}
        </tbody>
        <tfoot>
        </tfoot>
        `;
    }
}