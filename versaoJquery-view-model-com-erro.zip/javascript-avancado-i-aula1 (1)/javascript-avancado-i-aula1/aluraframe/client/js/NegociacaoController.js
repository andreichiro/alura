class NegociacaoController {
    constructor() {
        this.tbody = $("table tbody");
        this.formulario = $(".form");
        this.formulario.submit(this.adicionaCampos);
        
        this.NegociacaoView = new NegociacaoView($("#NegociacaoView"));
        this.NegociacaoView.update(this.negociacao);
        this.Mensagem = new Mensagem();
        this.MensagemView = new MensagemView();
        this.MensagemView.update(this.Mensagem);
    }

    adicionaCampos = (event) => {
        event.preventDefault();
        var data = DateHelper.textoParaData($("#data").val());
        var quantidade = $("#quantidade").val();
        var valor = $("#valor").val();
        var volume = quantidade * valor;
        var negociacao = {
            data,
            quantidade,
            valor,
            volume,
        };

        this.NegociacaoView.update(this.negociacao);  
        this.Mensagem.texto = 'Negociacao Adicionada com Sucesso';
        this.MensagemView.update(this.Mensagem);

        let diaMesAno = DateHelper.dataParaTexto(negociacao.data);

        this.tbody.append(`
        <tr>
            <td>${negociacao.data}</td>
            <td>${negociacao.quantidade}</td>
            <td>${negociacao.valor}</td>
            <td>${negociacao.volume}</td>
        </tr>
        `);
    }   
}