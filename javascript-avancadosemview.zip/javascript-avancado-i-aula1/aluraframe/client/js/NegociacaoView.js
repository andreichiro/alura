class NegociacaoView {

    constructor(event){
    }

    adicionaCampos = (event) => {
        event.preventDefault();
        var data = DateHelper.textoParaData($("#data").val());
        var quantidade = $("#quantidade").val();
        var valor = $("#valor").val();
        var volume = quantidade * valor;
        var negociacoes = new Negociacao(data, quantidade, valor, volume);
        console.log(negociacoes);

        this.tbody.append(`
        <tr>
            <td>${negociacoes.data}</td>
            <td>${negociacoes.quantidade}</td>
            <td>${negociacoes.valor}</td>
            <td>${negociacoes.volume}</td>
        </tr>
        `);
    }

    adicionaTitulos = (event) => {
            event.preventDefault();
            this.thead.append(`
            <tr>
                <th>DATA</th>
                <th>QUANTIDADE</th>
                <th>VALOR</th>
                <th>VOLUME</th>
            </tr>
            `);
    }   



}