class Negociacao {

    constructor(data, quantidade, valor, volume) {
        
        this.negociacoes = [
            this.data = data,
            this.quantidade = quantidade,
            this.valor = valor,
            this.volume = volume
        ];
    }    
}