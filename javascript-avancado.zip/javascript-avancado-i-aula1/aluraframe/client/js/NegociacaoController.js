class NegociacaoController {
    constructor() {
        this.formulario = $(".form");
        this.tbody = $("table tbody");    
    }
    
    adicionaCampos() {
        formulario.submit(function(event) {
            event.preventDefault();
            var data = $("#data").val();
            var quantidade = $("#quantidade").val();
            var valor = $("#valor").val();
            var volume = quantidade * valor;
            var negociacao = {
                data,
                quantidade,
                valor,
                volume,
            };
    
        });

        tbody.append(`
        <tr>
            <td>${negociacao.data}</td>
            <td>${negociacao.quantidade}</td>
            <td>${negociacao.valor}</td>
            <td>${negociacao.volume}</td>
        </tr>
        `);
    }   
}